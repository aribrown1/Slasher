package sample;


import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

class FXNetClientTest {

    FXNetClient fxnet;

    @Before
    void setup(){
        fxnet = new FXNetClient();
    }

    @Test
    void testTitleChanged() {
        assertEquals("title changed should be false", false, fxnet.returnTitlechanged());
    }

    @Test
    void testAssignedID() {
        assertEquals("assigned ID should be false", false, fxnet.returnAssignedID());
    }



}