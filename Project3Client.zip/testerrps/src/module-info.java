module testerrps {

    requires javafx.fxml;
    requires javafx.controls;

    opens sample;
}